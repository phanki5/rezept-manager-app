package com.example.rezept_manager.data.model;

public class Rezept {
    public String titel;
    public String kategorie;
    public String dauer;
    public String zutaten;
    public String zubereitung;

    public Rezept() {
        // Leerer Konstruktor für Firebase
    }

    public Rezept(String titel, String kategorie, String dauer, String zutaten, String zubereitung) {
        this.titel = titel;
        this.kategorie = kategorie;
        this.dauer = dauer;
        this.zutaten = zutaten;
        this.zubereitung = zubereitung;
    }

    public String getTitel() { return titel; }
    public String getKategorie() { return kategorie; }
    public String getDauer() { return dauer; }
    public String getZutaten() { return zutaten; }
    public String getZubereitung() { return zubereitung; }
}

