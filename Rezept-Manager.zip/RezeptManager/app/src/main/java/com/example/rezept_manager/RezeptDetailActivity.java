package com.example.rezept_manager;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class RezeptDetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rezept_detail);

        // Referenzen zu allen TextViews im Layout
        TextView title = findViewById(R.id.detailTitle);
        TextView category = findViewById(R.id.detailCategory);
        TextView time = findViewById(R.id.detailTime);
        TextView ingredients = findViewById(R.id.detailIngredients);
        TextView instructions = findViewById(R.id.detailInstructions);

        // Zurück-Button schließt die Activity
        Button backButton = findViewById(R.id.backButton);
        backButton.setOnClickListener(v -> finish());

        // Rezeptdaten aus dem Intent (Extras) abrufen
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            // Werte aus dem Bundle holen und in den TextViews anzeigen
            title.setText(extras.getString("titel"));
            category.setText("Kategorie: " + extras.getString("kategorie"));
            time.setText("Dauer: " + extras.getString("dauer"));
            ingredients.setText("Zutaten:\n" + extras.getString("zutaten"));
            instructions.setText("Zubereitung:\n" + extras.getString("zubereitung"));
        }
    }
}
