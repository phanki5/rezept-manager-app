package com.example.rezept_manager;

import android.os.Bundle;
import android.view.View;
import android.widget.*;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.rezept_manager.data.model.Rezept;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.*;

import java.util.Arrays;
import java.util.List;

public class EditRezeptActivity extends AppCompatActivity {

    private EditText titleField, timeField, ingredientsField, instructionsField;
    private Spinner categorySpinner;
    private Button saveButton;

    private String originalTitle;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_rezept);

        //Zurück-Button
        Button backButton = findViewById(R.id.backButton);
        backButton.setOnClickListener(v -> finish());

        // Felder initialisieren bzw verbinden
        titleField = findViewById(R.id.editTitle);
        timeField = findViewById(R.id.editTime);
        ingredientsField = findViewById(R.id.editIngredients);
        instructionsField = findViewById(R.id.editInstructions);
        categorySpinner = findViewById(R.id.categoryDropdown);
        saveButton = findViewById(R.id.saveButton);

        //kategorie
        List<String> categories = Arrays.asList(
                "Hauptgericht", "Vorspeise", "Dessert", "Snack",
                "Getränk", "Vegetarisch", "Vegan"
        );
        // Adapter verbindet Kategorienliste mit dem Spinner
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, categories);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        categorySpinner.setAdapter(adapter);

        // Daten vom Intent holen (aus LibraryFragment)
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            originalTitle = extras.getString("titel");
            titleField.setText(originalTitle);
            timeField.setText(extras.getString("dauer"));
            ingredientsField.setText(extras.getString("zutaten"));
            instructionsField.setText(extras.getString("zubereitung"));
           //dropdown ist default
        }

        // Speichern (Klick listener für button)
        saveButton.setOnClickListener(v -> {
            String newTitle = titleField.getText().toString().trim();
            String newTime = timeField.getText().toString().trim();
            String newIngredients = ingredientsField.getText().toString().trim();
            String newInstructions = instructionsField.getText().toString().trim();
            String selectedCategory = categorySpinner.getSelectedItem().toString();

            // Eiingabe prüfen
            if (newTitle.isEmpty() || newTime.isEmpty() || newIngredients.isEmpty() || newInstructions.isEmpty()) {
                Toast.makeText(this, "Bitte alle Felder ausfüllen", Toast.LENGTH_SHORT).show();
                return;
            }

            String userId = FirebaseAuth.getInstance().getCurrentUser().getUid();
            DatabaseReference dbRef = FirebaseDatabase.getInstance().getReference("Rezepte").child(userId);

            // Zuerst altes Rezept löschen
            dbRef.orderByChild("titel").equalTo(originalTitle).addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    for (DataSnapshot snap : snapshot.getChildren()) {
                        snap.getRef().removeValue(); // löschen
                    }

                    // Neues Rezept speichern
                    Rezept updatedRezept = new Rezept(newTitle, selectedCategory, newTime, newIngredients, newInstructions);
                    dbRef.push().setValue(updatedRezept)
                            .addOnSuccessListener(unused -> {
                                Toast.makeText(EditRezeptActivity.this, "Rezept aktualisiert", Toast.LENGTH_SHORT).show();
                                finish(); // zurück zur vorherigen Ansicht
                            })
                            .addOnFailureListener(e -> {
                                Toast.makeText(EditRezeptActivity.this, "Fehler beim Speichern", Toast.LENGTH_SHORT).show();
                            });
                }
                //Fehlermeldung
                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    Toast.makeText(EditRezeptActivity.this, "Fehler beim Löschen", Toast.LENGTH_SHORT).show();
                }
            });
        });


    }

}
