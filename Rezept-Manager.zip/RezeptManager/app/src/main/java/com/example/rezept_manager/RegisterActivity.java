package com.example.rezept_manager;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.rezept_manager.databinding.ActivityRegisterBinding;
import com.example.rezept_manager.MainActivity;
import com.google.firebase.auth.FirebaseAuth;

public class RegisterActivity extends AppCompatActivity {

    // ViewBinding-Objekt für direkten Zugriff auf alle UI-Elemente im XML
    private ActivityRegisterBinding binding;
    private FirebaseAuth auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Binding initialisieren: Verbindet Java-Code mit dem Layout (activity_register.xml)
        binding = ActivityRegisterBinding.inflate(getLayoutInflater());
        // Layout anzeigen
        setContentView(binding.getRoot());

        auth = FirebaseAuth.getInstance();

        //Klick-Listener für den Registrieren-Button → führt die Registrierungsmethode aus
        binding.registerButton.setOnClickListener(v -> registerUser());
        //"Zurück zum Login" Button → Zurück zur LoginActivity
        binding.backToLoginButton.setOnClickListener(v ->
                finish()
        );
    }

    private void registerUser() {
        // E-Mail und Passwörter aus den Textfeldern holen
        String email = binding.usernameRegister.getText().toString().trim();
        String password = binding.passwordRegister.getText().toString().trim();
        String password2 = binding.passwordRepeatRegister.getText().toString().trim();

        // checkt ob Textfelder leer sind
        if (TextUtils.isEmpty(email) || TextUtils.isEmpty(password) || TextUtils.isEmpty(password2)) {
            Toast.makeText(this, "Bitte E-Mail und beide Passwörter eingeben", Toast.LENGTH_SHORT).show();
            return;
        }
        // Prüft ob Passwörter übereinstimmen
        if (!password.equals(password2)) {
            Toast.makeText(this, "Passwörter stimmen nicht überein", Toast.LENGTH_SHORT).show();
            return;
        }

        // Passwortlänge prüfen
        if (password.length() < 6) {
            Toast.makeText(this, "Passwort muss mindestens 6 Zeichen haben", Toast.LENGTH_SHORT).show();
            return;
        }

        // registriert User in Firebase
        auth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        Toast.makeText(this, "Registrierung erfolgreich", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(RegisterActivity.this, MainActivity.class));
                        finish();
                    } else {
                        // Fehlermeldung wenn Registrierung fehlgeschlagen ist
                        Toast.makeText(this, "Fehler: " + task.getException().getMessage(),
                                Toast.LENGTH_LONG).show();
                    }
                });
    }
}
