package com.example.rezept_manager;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;
import android.widget.EditText;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.example.rezept_manager.data.model.Rezept;

import androidx.fragment.app.Fragment;

import java.util.Arrays;
import java.util.List;

public class AddFragment extends Fragment {

    public AddFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Layout aufbauen
        View view = inflater.inflate(R.layout.fragment_add, container, false);

        // Spinner aus dem Layout holen
        Spinner categoryDropdown = view.findViewById(R.id.categoryDropdown);

        // Kategorie liste
        List<String> categories = Arrays.asList(
                "Hauptgericht", "Vorspeise", "Dessert", "Snack",
                "Getränk", "Vegetarisch", "Vegan"
        );

        // Adapter für Spinner
        ArrayAdapter<String> adapter = new ArrayAdapter<>(getContext(),android.R.layout.simple_spinner_item, categories);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        categoryDropdown.setAdapter(adapter);


        Button saveButton = view.findViewById(R.id.saveRecipeButton);
        // Speichern funktion
        saveButton.setOnClickListener(v -> {
            String titel = ((EditText) view.findViewById(R.id.recipeTitle)).getText().toString().trim();
            String kategorie = ((Spinner) view.findViewById(R.id.categoryDropdown)).getSelectedItem().toString();
            String dauer = ((EditText) view.findViewById(R.id.recipeTime)).getText().toString().trim();
            String zutaten = ((EditText) view.findViewById(R.id.ingredients)).getText().toString().trim();
            String zubereitung = ((EditText) view.findViewById(R.id.instructions)).getText().toString().trim();

            //alle felder müssen ausgefüllt sein (prüfung)
            if (titel.isEmpty() || dauer.isEmpty() || zutaten.isEmpty() || zubereitung.isEmpty()) {
                Toast.makeText(getContext(), "Bitte alle Felder ausfüllen", Toast.LENGTH_SHORT).show();
                return;
            }
            //neues Rezept-Objekt
            Rezept rezept = new Rezept(titel, kategorie, dauer, zutaten, zubereitung);

            String userId = FirebaseAuth.getInstance().getCurrentUser().getUid();
            DatabaseReference dbRef = FirebaseDatabase.getInstance().getReference("Rezepte").child(userId);

            // Push neues Rezept auf db
            dbRef.push().setValue(rezept).addOnSuccessListener(unused -> {
                Toast.makeText(getContext(), "Rezept gespeichert", Toast.LENGTH_SHORT).show();
            }).addOnFailureListener(e -> {
                Toast.makeText(getContext(), "Fehler beim Speichern", Toast.LENGTH_SHORT).show();
            });
        });


        return view;
    }
}
