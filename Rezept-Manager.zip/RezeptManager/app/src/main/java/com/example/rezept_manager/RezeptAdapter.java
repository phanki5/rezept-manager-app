package com.example.rezept_manager;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.rezept_manager.data.model.Rezept;

import java.util.List;

public class RezeptAdapter extends RecyclerView.Adapter<RezeptAdapter.RezeptViewHolder> {

    private Context context; // Activity oder Fragment
    private List<Rezept> rezeptListe; // Liste der Rezepte
    private OnRezeptActionListener listener; // Interface für Klick-Listener

    //Button funktionen
    public interface OnRezeptActionListener {
        void onEditClicked(Rezept rezept);// wird jetzt vom Button getriggert
        void onDeleteClicked(Rezept rezept);// wird jetzt vom Button getriggert
        void onItemClicked(Rezept rezept); // wird jetzt vom Button getriggert
    }
    //Konstruktor
    public RezeptAdapter(Context context, List<Rezept> rezeptListe, OnRezeptActionListener listener) {
        this.context = context;
        this.rezeptListe = rezeptListe;
        this.listener = listener;
    }

    @NonNull
    @Override
    public RezeptViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        //Layout aufblasen
        View itemView = LayoutInflater.from(context).inflate(R.layout.item_rezept, parent, false);
        return new RezeptViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull RezeptViewHolder holder, int position) {
        // Rezept für die Aktuelle posiition holen
        Rezept rezept = rezeptListe.get(position);
        // Daten in die Textfelder einfügen
        holder.titleText.setText(rezept.getTitel());
        holder.categoryText.setText(rezept.getKategorie());

        holder.detailsButton.setOnClickListener(v -> listener.onItemClicked(rezept)); //Rezept-details anzeigen
        holder.editButton.setOnClickListener(v -> listener.onEditClicked(rezept));//Rezept bearbeiten
        holder.deleteButton.setOnClickListener(v -> listener.onDeleteClicked(rezept));//Rezept löschen
    }
    // Methode, um gefilterte oder geänderte Listen anzuzeigen
    public void updateList(List<Rezept> neueListe) {
        rezeptListe = neueListe;
        notifyDataSetChanged();
    }
    @Override
    //Anzahl der Rezepte, wichtig für RecycleView
    public int getItemCount() {
        return rezeptListe.size();
    }


     //ViewHolder-Klasse: hält Referenzen zu den UI-Elementen,
     //damit RecyclerView nicht jedes Mal findViewById() aufrufen muss
    public static class RezeptViewHolder extends RecyclerView.ViewHolder {
        TextView titleText, categoryText;
        Button detailsButton, editButton, deleteButton;

        public RezeptViewHolder(@NonNull View itemView) {
            super(itemView);
            titleText = itemView.findViewById(R.id.titleText);
            categoryText = itemView.findViewById(R.id.categoryText);
            detailsButton = itemView.findViewById(R.id.detailsButton);
            editButton = itemView.findViewById(R.id.editButton);
            deleteButton = itemView.findViewById(R.id.deleteButton);
        }


    }
}
