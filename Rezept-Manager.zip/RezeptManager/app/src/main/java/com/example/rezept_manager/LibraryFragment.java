package com.example.rezept_manager;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.rezept_manager.data.model.Rezept;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.*;

import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;

import java.util.ArrayList;
import java.util.List;

public class LibraryFragment extends Fragment {

    private RecyclerView recyclerView;
    private RezeptAdapter adapter;
    private List<Rezept> rezeptListe;
    private DatabaseReference rezepteRef;

    public LibraryFragment() {}

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // inflate layout für das Fragment
        View view = inflater.inflate(R.layout.fragment_library, container, false);

        //recycle view einrichten
        recyclerView = view.findViewById(R.id.recipeRecyclerView);
        rezeptListe = new ArrayList<>();
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        // Firebase-referenz auf die Rezepte vom eingeloggten User
        String userId = FirebaseAuth.getInstance().getCurrentUser().getUid();
        rezepteRef = FirebaseDatabase.getInstance().getReference("Rezepte").child(userId);

        //adapter mit Klick-Listener
        adapter = new RezeptAdapter(getContext(), rezeptListe, new RezeptAdapter.OnRezeptActionListener() {
            @Override
            public void onEditClicked(Rezept rezept) {
                //rezept daten werden "angehängt" an EditRezeptActivity
                Intent intent = new Intent(getContext(), EditRezeptActivity.class);
                intent.putExtra("titel", rezept.getTitel());
                intent.putExtra("kategorie", rezept.getKategorie());
                intent.putExtra("dauer", rezept.getDauer());
                intent.putExtra("zutaten", rezept.getZutaten());
                intent.putExtra("zubereitung", rezept.getZubereitung());
                startActivity(intent);
            }

            @Override
            public void onDeleteClicked(Rezept rezept) {
                //Rezept wird aus Firebase gelöscht anhand Titel
                rezepteRef.orderByChild("titel").equalTo(rezept.getTitel()).addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        for (DataSnapshot snap : snapshot.getChildren()) {
                            snap.getRef().removeValue();
                        }
                        Toast.makeText(getContext(), "Rezept gelöscht", Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        Toast.makeText(getContext(), "Fehler beim Löschen", Toast.LENGTH_SHORT).show();
                    }
                });
            }

            @Override
            public void onItemClicked(Rezept rezept) {
                //Rezept details anzeigen (durch "anhängen" wieder)
                Intent intent = new Intent(getContext(), RezeptDetailActivity.class);
                intent.putExtra("titel", rezept.getTitel());
                intent.putExtra("kategorie", rezept.getKategorie());
                intent.putExtra("dauer", rezept.getDauer());
                intent.putExtra("zutaten", rezept.getZutaten());
                intent.putExtra("zubereitung", rezept.getZubereitung());
                startActivity(intent);
            }
        });

        recyclerView.setAdapter(adapter);
        // Firebase-Datenlistener (lädt Rezepte und aktualisiert die Liste bei Änderungen)
        rezepteRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                rezeptListe.clear();
                for (DataSnapshot snap : snapshot.getChildren()) {
                    Rezept rezept = snap.getValue(Rezept.class);
                    rezeptListe.add(rezept);
                }
                adapter.notifyDataSetChanged(); //aktualiesiert die Anzeige
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(getContext(), "Fehler beim Laden", Toast.LENGTH_SHORT).show();
            }
        });

        // Search funktion
        EditText searchField = view.findViewById(R.id.searchField);
        searchField.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                filterList(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });
        return view;
    }

    //filtert-liste-Funktion bei Suche
    private void filterList(String text) {
        List<Rezept> filteredList = new ArrayList<>();
        for (Rezept rezept : rezeptListe) {
            if (rezept.getTitel().toLowerCase().contains(text.toLowerCase()) ||
                    rezept.getKategorie().toLowerCase().contains(text.toLowerCase())) {
                filteredList.add(rezept);
            }
        }
        adapter.updateList(filteredList);
    }
}
