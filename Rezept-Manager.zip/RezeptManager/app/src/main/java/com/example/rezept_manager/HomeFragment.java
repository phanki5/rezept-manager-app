package com.example.rezept_manager;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.firebase.auth.FirebaseAuth;

public class HomeFragment extends Fragment {

    public HomeFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView( LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate layout
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        // Firebase-User holen
        String email = FirebaseAuth.getInstance().getCurrentUser().getEmail();

        // Begrüßungstext
        TextView greetingText = view.findViewById(R.id.greetingTextView);
        greetingText.setText("Willkommen, " + email + "!\n\nNavigiere dich durch die App unten an der Navigationsleiste.");

        return view;
    }
}
